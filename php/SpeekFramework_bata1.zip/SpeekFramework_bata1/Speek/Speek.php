<?php
/*-------------------------Speek-----------------------！
 * 创建日期 2011-3-14
 *
 * 作者 白某人 QQ:562330198 因为交流，所以成长!
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
!defined('SPEEK_PATH') && define('SPEEK_PATH',str_replace('\\', '/', dirname(__FILE__)));
//------------------引入相关文件---------------------！
require SPEEK_PATH.'/Configs/Config.php';
require SPEEK_PATH.'/Configs/Control.class.php';
require SPEEK_PATH.'/Configs/Model.class.php';
require SPEEK_PATH.'/Configs/templates/Smarty.class.php';
require SPEEK_PATH.'/Configs/View.class.php';
//------------------引入文件结束---------------------！
?>
