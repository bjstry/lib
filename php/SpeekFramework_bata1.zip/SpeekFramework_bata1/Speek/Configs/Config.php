<?php
/*-------------------------Speek-----------------------！
 * 创建日期 2011-3-14
 *
 * 作者 白某人 QQ:562330198 因为交流，所以成长!
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
 $K = array(
	'URL_MODE'					=> 3,			              //URL模式, 1普通模式, 2 PATH_INFO模式，3 通用模式
	'DEFAULT_CONTROL'			=> 'index',		              //默认调用的控制器
	'DEFAULT_METHOD'			=> 'index',		              //默认执行的方法
	'DEFAULT_VIEW'              => 'default',                 //默认采用模板
	'cach'                      => 'false',                   //模板引擎是否使用缓存
	'template'                  => SPEEK_PATH.'/templates',    //模板引擎模板目录
	'compile'                   => SPEEK_PATH.'/templates_c',  //模板引擎编译目录
	'cache'                     => SPEEK_PATH.'/Speek_cache',  //模板引擎缓存目录
	's_left'                    => '{',                       //左边界符
	's_right'                   => '}',                       //右边界符
	'dbtype'                    => 'mysql',
	'dbhost'                    => 'localhost',
	'dbname'                    => '',
	'dbuser'                    => 'root',
	'dbpass'                    => '',
	'dbbian'                    => 'GBK'
 );
?>



