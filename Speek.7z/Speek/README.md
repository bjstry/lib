SpeekFrame 

steep 1 <br>
create index.php file <br>

steep 2 <br>
edit index.php <br>

define('PRJ','Home'); <br>
require './Speek/Speek.php'; <br><br><br>

 Author Jinsong <br>
Version BETA3 <br>
 Update 2015-03-02 11:04 
